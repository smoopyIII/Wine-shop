package com.example.progettodbfx;

import javafx.application.Application;
import javafx.stage.Stage;
import java.time.LocalDate;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ConcurrentServer extends Application {
    @Override
    public void start(Stage stage) throws IOException{
        // crea un server sulla porta 1234
        final String DBURL = "jdbc:mysql://127.0.0.1:3306/Wineshop?";
        final String ARGS = "createDatabaseIfNotExist=true&serverTimezone=UTC";
        final String LOGIN = "root";
        final String PASSWORD = "";

        try (Connection conn = DriverManager.getConnection(DBURL + ARGS, LOGIN, PASSWORD); Statement stmt = conn.createStatement();) {
            ServerSocket serverSocket = new ServerSocket(4444, 20);


            while (true) {
                final Socket socket = serverSocket.accept();

                new Thread(new Runnable() {
                    public void run() {
                        try {
                            Scanner in = new Scanner(socket.getInputStream());
                            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                            // ciclo di gestione della connessione del client
                            while (true) {
                                String line = in.nextLine();

                                if (line.equals("SHOW_WINES")) {
                                    String strSelect = "SELECT * FROM wines";
                                    ResultSet rset = stmt.executeQuery(strSelect);

                                    while (rset.next()) {
                                        String data = rset.getInt("id") + "/" + rset.getString("name") + "/" + rset.getString("producer") + "/" + rset.getString("origin") + "/" + rset.getInt("year") + "/" + rset.getString("tecnical_notes") + "/" + rset.getString("grapes") + "/" + rset.getInt("prize") + "/" + rset.getInt("availability");
                                        out.println(data);
                                    }
                                    out.println("null");
                                }

                                else if (line.equals("RESET_PASSWORD")) {

                                    String username = in.nextLine();
                                    String phone_number = in.nextLine();

                                    System.out.println(username);
                                    System.out.println(phone_number);

                                    //controllare se esiste l'utente nella tabella clients o nella tabella employees
                                    String strSelect = "SELECT * FROM clients WHERE clients.username='" + username + "' AND clients.phone_number='" + phone_number + "'";
                                    ResultSet rset = stmt.executeQuery(strSelect);
                                    int cont=0;
                                    String password = null;
                                    while (rset.next()) {
                                        password=rset.getString("clients.password");
                                        cont++;
                                    }
                                    System.out.println(cont);
                                    if(cont!=0)
                                        out.println(password);
                                    else
                                    //controllare se esiste l'utente nella tabella employees
                                    {
                                        strSelect = "SELECT * FROM employees WHERE employees.username='" + username + "' AND employees.phone_number='" + phone_number + "'";
                                        rset = stmt.executeQuery(strSelect);
                                        cont=0;
                                        while (rset.next()) {
                                            password=rset.getString("employees.password");
                                            cont++;
                                        }
                                        System.out.println(cont);
                                        if(cont!=0)
                                            out.println(password);
                                        else
                                            out.println("null");
                                    }
                                }
                                else if(line.equals("SHOW_WINES_BY_NAME"))
                                {
                                    String strSelect="";
                                    int yearwinetosearch=0;
                                    String namewinetosearch = in.nextLine();
                                    String year = in.nextLine();

                                    System.out.println("name: " + namewinetosearch + ", year: "+ year);


                                    if(!year.equals("null")){
                                        yearwinetosearch = Integer.parseInt(year);
                                    }


                                    if((!namewinetosearch.equals("")) && (yearwinetosearch>1989 && yearwinetosearch<2024)) {
                                        System.out.println("primo if");
                                        strSelect = "SELECT * FROM wines WHERE wines.name LIKE '%" + namewinetosearch + "%' AND wines.year = '" + yearwinetosearch + "'";
                                    }else if(yearwinetosearch>1989 && yearwinetosearch<2024) {
                                        System.out.println("secondo if");
                                        strSelect = "SELECT * FROM wines WHERE wines.year = '" + yearwinetosearch + "'";
                                    }else{
                                        System.out.println("terzo if");
                                        strSelect = "SELECT * FROM wines WHERE wines.name LIKE '%" + namewinetosearch + "%'";
                                    }

                                    ResultSet rset = stmt.executeQuery(strSelect);

                                    while (rset.next()) {
                                        String data = rset.getInt("id") + "/" + rset.getString("name") + "/" + rset.getString("producer") + "/" + rset.getString("origin") + "/" + rset.getInt("year") + "/" + rset.getString("tecnical_notes") + "/" + rset.getString("grapes") + "/" + rset.getInt("prize") + "/" + rset.getInt("availability");
                                        System.out.println("info: " + data);
                                        out.println(data);
                                    }
                                    out.println("null");
                                }
                                else if (line.equals("SEARCH_WINES")) {
                                    int trovato = 0;
                                    line = in.nextLine();
                                    String strselect = "SELECT * FROM wines WHERE wines.name='" + line + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        trovato = 1;
                                        String data = rset.getInt("id") + " " + rset.getString("name") + " " + rset.getString("producer") + " " + rset.getString("origin") + " " + rset.getInt("year") + " " + rset.getString("tecnical_notes") + " " + rset.getString("grapes") + " " + rset.getInt("prize");
                                        out.println(data);
                                    }
                                    if (trovato == 0)
                                        out.println("La sua ricerca non ha prodotto risultati");
                                    out.println("null");

                                }
                                else if (line.equals("SHOW_CLIENT")) {
                                    int trovato = 0;
                                    line = in.nextLine();
                                    String strselect = "SELECT * FROM clients WHERE clients.surname='" + line + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        trovato = 1;
                                        String data = rset.getInt("id") + "/" + rset.getString("name") + "/" + rset.getString("surname") + "/" + rset.getString("fiscal_code") + "/"+ rset.getString("email") + "/" + rset.getString("phone_number") + "/" + rset.getString("delivery_address");
                                        out.println(data);
                                        System.out.println(data);
                                    }
                                    if (trovato == 0)
                                        out.println("La sua ricerca non ha prodotto risultati");
                                    out.println("null");

                                }
                                else if (line.equals("SEARCH_PURCHASES")) {
                                    int trovato = 0;

                                    String id = in.nextLine();
                                    String strSelect = "SELECT * FROM clients WHERE clients.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strSelect);
                                    String name = "", surname = "";
                                    while (rset.next()) {
                                        name = rset.getString("name");
                                        surname = rset.getString("surname");
                                    }
                                    //strSelect = "SELECT * FROM purchases WHERE purchases.cid='" + id + "'";
                                    strSelect = "SELECT purchases.id, wines.name, purchases.date, purchases.value, purchases.quantity FROM purchases INNER JOIN clients ON purchases.cid = clients.id INNER JOIN wines ON purchases.product = wines.id WHERE purchases.cid='" + id + "'";

                                    rset = stmt.executeQuery(strSelect);

                                    while (rset.next()) {
                                        trovato = 1;
                                        String data = rset.getInt("purchases.id") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases.date") + "/" + rset.getDouble("purchases.value") + "/" + rset.getInt("purchases.quantity");
                                        out.println(data);
                                    }
                                    if (trovato == 0)
                                        out.println("NO_RESULT");
                                    out.println("null");

                                }

                                else if (line.equals("SEARCH_CLIENT")) {
                                    int trovato = 0;
                                    line = in.nextLine();
                                    String strselect = "SELECT * FROM clients WHERE clients.surname LIKE '%" + line + "%'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        trovato = 1;

                                        String data = rset.getInt("id") + "/" + rset.getString("name") + "/" + rset.getString("surname") + "/" + rset.getString("delivery_address") + "/" + rset.getString("phone_number") + "/"+ rset.getString("fiscal_code") + "/" + rset.getString("email");
                                        out.println(data);

                                    }
                                    if (trovato == 0)
                                        out.println("La sua ricerca non ha prodotto risultati");
                                    out.println("null");
                                }
                                else if (line.equals("GET_ADMIN_DATA")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM admins WHERE admins.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();
                                    String name = rset.getString("name");
                                    String surname = rset.getString("surname");
                                    String delivery_address = rset.getString("address");
                                    String phone_number = rset.getString("phone_number");
                                    String fiscal_code = rset.getString("fiscal_code");
                                    String email = rset.getString("email");
                                    String username = rset.getString("username");
                                    //String password = rset.getString("password");
                                    out.println(name);
                                    out.println(surname);
                                    out.println(delivery_address);
                                    out.println(phone_number);
                                    out.println(fiscal_code);
                                    out.println(email);
                                    out.println(username);
                                    //out.println(password);
                                }
                                else if (line.equals("GET_CLIENT_DATA"))    {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM clients WHERE clients.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();
                                    String name = rset.getString("name");
                                    String surname = rset.getString("surname");
                                    String delivery_address = rset.getString("delivery_address");
                                    String phone_number = rset.getString("phone_number");
                                    String fiscal_code = rset.getString("fiscal_code");
                                    String email = rset.getString("email");
                                    String username = rset.getString("username");
                                    //String password = rset.getString("password");
                                    out.println(name);
                                    out.println(surname);
                                    out.println(delivery_address);
                                    out.println(phone_number);
                                    out.println(fiscal_code);
                                    out.println(email);
                                    out.println(username);
                                    //out.println(password);
                                }
                                else if (line.equals("GET_EMPLOYEE_DATA")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM employees WHERE employees.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();
                                    String name = rset.getString("name");
                                    String surname = rset.getString("surname");
                                    String address = rset.getString("address");
                                    String phone_number = rset.getString("phone_number");
                                    String fiscal_code = rset.getString("fiscal_code");
                                    String email = rset.getString("email");
                                    String username = rset.getString("username");
                                    //String password = rset.getString("password");
                                    out.println(name);
                                    out.println(surname);
                                    out.println(address);
                                    out.println(phone_number);
                                    out.println(fiscal_code);
                                    out.println(email);
                                    out.println(username);
                                    //out.println(password);
                                }

                                else if (line.equals("GET_CLIENT_USERNAME")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM clients WHERE clients.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();

                                    String username = rset.getString("username");
                                    out.println(username);
                                }

                                else if (line.equals("GET_EMPLOYEE_USERNAME")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM employees WHERE employees.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();

                                    String username = rset.getString("username");
                                    out.println(username);
                                }
                                else if (line.equals("CHECK_OLD_PASSWORD")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM employees WHERE employees.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();

                                    String password = rset.getString("password");
                                    out.println(password);
                                }
                                else if (line.equals("CHECK_OLD_ADMIN_PASSWORD")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT * FROM admins WHERE admins.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    rset.next();

                                    String password = rset.getString("password");
                                    out.println(password);
                                }

                                else if (line.equals("UPDATE_PASSWORD")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String newPassword = in.nextLine();
                                    String strselect = "UPDATE employees SET password='" + newPassword + "' WHERE employees.id='" + id + "'";
                                    stmt.executeUpdate(strselect);
                                }
                                else if (line.equals("UPDATE_ADMIN_PASSWORD")) {
                                    int id = 0;
                                    id = Integer.parseInt(in.nextLine());
                                    String newPassword = in.nextLine();
                                    String strselect = "UPDATE admins SET password='" + newPassword + "' WHERE admins.id='" + id + "'";
                                    stmt.executeUpdate(strselect);
                                }

                                else if (line.equals("SHOW_PROPOSAL")) {
                                    int trovato = 0;
                                    int id = Integer.parseInt(in.nextLine());
                                    String strselect = "SELECT proposal_tmp.id, wines.name ,wines.producer, proposal_tmp.quantity, proposal_tmp.value, clients.name FROM proposal_tmp JOIN wines ON proposal_tmp.product = wines.id JOIN clients ON proposal_tmp.cid = clients.id WHERE proposal_tmp.cid = '" + id + "' ORDER BY proposal_tmp.id";
                                    System.out.println("strselect: " + strselect);
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        trovato = 1;
                                        String data = rset.getInt("proposal_tmp.id") + "/" + rset.getString("wines.name") + "/" + rset.getString("wines.producer") + "/" + rset.getInt("proposal_tmp.quantity") + "/" + rset.getFloat("proposal_tmp.value") + "/" + rset.getString("clients.name");
                                        out.println(data);
                                        System.out.println("daat: "+ data);
                                    }
                                    if (trovato == 0)
                                        out.println("NO_PROPOSALS");
                                    out.println("null");
                                }

                                else if (line.equals("SHOW_ALL_PROPOSAL")) {
                                    int trovato = 0;
                                    line = in.nextLine();
                                    String strselect = "SELECT proposal2.id, wines.name ,wines.producer, proposal2.quantity, proposal2.value, clients.name FROM proposal2 JOIN wines ON proposal2.product = wines.id JOIN clients ON proposal2.cid = clients.id ORDER BY proposal2.id";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        trovato = 1;
                                        String data = rset.getInt("proposal2.id") + "/" + rset.getString("wines.name") + "/" + rset.getString("wines.producer") + "/" + rset.getInt("proposal2.quantity") + "/" + rset.getFloat("proposal2.value") + "/" + rset.getString("clients.name");
                                        out.println(data);
                                        System.out.println("daat: "+ data);
                                    }
                                    if (trovato == 0)
                                        out.println("NO_PROPOSALS");
                                    out.println("null");
                                }

                                else if (line.equals("CHECK_VALUE")) {
                                    String id = in.nextLine();
                                    int quantityrecived= Integer.parseInt(in.nextLine());
                                    String strSelect = "SELECT wines.* FROM wines WHERE wines.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strSelect);

                                    int quantity=0;
                                    while (rset.next()) {
                                        quantity = Integer.parseInt(rset.getString("availability"));
                                        if(quantity-quantityrecived >= 0)
                                        {
                                            out.println("ENOUGHT");
                                        }
                                        else
                                        {
                                            out.println("PURCHASE_PROPOSAL");
                                        }
                                    }
                                }

                                else if (line.equals("SEARCH_USERNAME")) {
                                    String username = in.nextLine();
                                    String strSelect = "SELECT * FROM clients WHERE clients.username='" + username + "'";
                                    ResultSet rset = stmt.executeQuery(strSelect);
                                    int cont=0;
                                    while (rset.next()) {
                                        cont++;
                                    }
                                    if (cont==0)
                                        out.println("null");
                                    else
                                        out.println("finded");
                                }
                                else if(line.equals("SIGNUP")) {

                                    int contclients = 0;

                                    String name = in.nextLine();
                                    String surname = in.nextLine();
                                    String fiscalcode = in.nextLine();
                                    String email = in.nextLine();
                                    String address = in.nextLine();
                                    String phonenumber = in.nextLine();
                                    String username = in.nextLine();
                                    String password = in.nextLine();

                                    String strSelect = "SELECT max(id) as id FROM clients";
                                    ResultSet rset = stmt.executeQuery(strSelect);

                                    while (rset.next()) {
                                        contclients = rset.getInt("id") + 1;
                                    }
                                    String insertSql = "insert into clients values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                    PreparedStatement pstmt = conn.prepareStatement(insertSql);
                                    Client c = new Client(contclients, name, surname, fiscalcode, email, address, phonenumber, username, password);

                                    pstmt.setInt(1, contclients);
                                    pstmt.setString(2, c.getName());
                                    pstmt.setString(3, c.getSurname());
                                    pstmt.setString(4, c.getFiscalCode());
                                    pstmt.setString(5, c.getEmail());
                                    pstmt.setString(6, c.getDeliveryAddress());
                                    pstmt.setString(7, c.getPhoneNumber());
                                    pstmt.setString(8, c.getUsername());
                                    pstmt.setString(9, c.getPassword());
                                    pstmt.addBatch();
                                    pstmt.executeBatch();


                                }

                                else if(line.equals("ADD_PRODUCT")) {
                                    int contproduct = 0;

                                    String name = in.nextLine();
                                    String producer = in.nextLine();
                                    String origin = in.nextLine();
                                    int year = Integer.parseInt(in.nextLine());
                                    String tecnicalnotes = in.nextLine();
                                    String grapes = in.nextLine();
                                    float price = Float.parseFloat(in.nextLine());
                                    int availability = Integer.parseInt(in.nextLine());

                                    String strSelect = "SELECT max(id) as id FROM wines";
                                    ResultSet rset = stmt.executeQuery(strSelect);

                                    while (rset.next()) {
                                        contproduct = rset.getInt("id") + 1;
                                    }

                                    String insertSql = "insert into wines values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                                    PreparedStatement pstmt = conn.prepareStatement(insertSql);
                                    Wine w = new Wine(contproduct, name, producer, origin, year, tecnicalnotes, grapes, price, availability);

                                    pstmt.setInt(1, contproduct);
                                    pstmt.setString(2, w.getName());
                                    pstmt.setString(3, w.getProducer());
                                    pstmt.setString(4, w.getOrigin());
                                    pstmt.setInt(5, w.getYear());
                                    pstmt.setString(6, w.getTechnicalNotes());
                                    pstmt.setString(7, w.getGrapes());
                                    pstmt.setFloat(8, w.getPrice());
                                    pstmt.addBatch();

                                    pstmt.executeBatch();
                                }

                                else if(line.equals("BUY_WINES")) {

                                    String id = in.nextLine();
                                    int quantity = Integer.parseInt(in.nextLine());
                                    int cid = Integer.parseInt(in.nextLine());
                                    int contpurchases=Integer.parseInt(in.nextLine());
                                    float price_tot=Float.parseFloat(in.nextLine());
                                    price_tot = (float) (Math.round(price_tot * 100.0) / 100.0);

                                    String date = String.valueOf(LocalDate.now());

                                    String insertSql = "insert into purchases values (?, ?, ?, ?, ?, ?)";
                                    PreparedStatement pstmt = conn.prepareStatement(insertSql);
                                    Purchase p = new Purchase(contpurchases, cid, id, date, quantity , price_tot);

                                    pstmt.setInt(1, contpurchases);
                                    pstmt.setInt(2, p.getCid());
                                    pstmt.setInt(3, Integer.parseInt(p.getProduct()));
                                    pstmt.setString(4, p.getDate());
                                    pstmt.setInt(5, p.getQuantity());
                                    pstmt.setDouble(6, p.getPrice());

                                    pstmt.addBatch();
                                    pstmt.executeBatch();

                                    String strSelect = "SELECT * FROM wines WHERE wines.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strSelect);
                                    int quantityrem=0;
                                    while (rset.next()) {
                                        quantityrem = rset.getInt("availability");
                                    }
                                    quantityrem = quantityrem - quantity;
                                    String updateSql = "UPDATE wines SET availability = ? WHERE id = ?";
                                    PreparedStatement pstmt2 = conn.prepareStatement(updateSql);
                                    pstmt2.setInt(1, quantityrem);
                                    pstmt2.setInt(2, Integer.parseInt(id));
                                    pstmt2.executeUpdate();

                                    String strSelect1 = "SELECT * FROM minquantity WHERE minquantity.id='" + id + "'";
                                    ResultSet rset1 = stmt.executeQuery(strSelect1);
                                    int minquantity=0;
                                    while (rset1.next()) {
                                        minquantity = rset1.getInt("minquantity");
                                    }

                                    if (quantityrem < minquantity) {
                                        String insertSql2 = "insert into wineToOrder values (?, ?, ?)";
                                        PreparedStatement pstmt3 = conn.prepareStatement(insertSql2);
                                        int counter = 0;
                                        String strSelect2 = "SELECT max(id) as id FROM wineToOrder";
                                        ResultSet rset2 = stmt.executeQuery(strSelect2);

                                        while (rset2.next()) {
                                            counter = rset2.getInt("id") + 1;
                                        }

                                        pstmt3.setInt(1, counter);
                                        pstmt3.setInt(2, Integer.parseInt(id));
                                        pstmt3.setInt(3, 10 - quantityrem);
                                        pstmt3.addBatch();
                                        pstmt3.executeBatch();

                                    }


                                }
                                else if(line.equals("PRICE_WINE")) {
                                    float price=0;
                                    String id = in.nextLine();
                                    String strSelect = "SELECT * FROM wines WHERE wines.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strSelect);

                                    while (rset.next()) {
                                        price = rset.getInt("prize");
                                    }
                                    out.println(price);
                                }

                                else if(line.equals("CONT_PROPOSAL")) {

                                    String strSelect = "SELECT max(id) as id FROM proposal2";
                                    ResultSet rset = stmt.executeQuery(strSelect);
                                    int contpurchases=0;

                                    rset.next();
                                    contpurchases = rset.getInt("id") + 1;
                                    out.println(contpurchases);
                                }
                                else if(line.equals("CONT_PURCHASES")) {

                                    String strSelect = "SELECT max(id) as id FROM purchases";
                                    ResultSet rset = stmt.executeQuery(strSelect);
                                    int contpurchases=0;

                                    rset.next();
                                    contpurchases = rset.getInt("id") + 1;
                                    out.println(contpurchases);
                                }
                                else if(line.equals("TMP_PURCHASE"))
                                {
                                    int idtmp=0;
                                    String strSelect = "SELECT max(id) as id FROM proposal_tmp";
                                    ResultSet rset1 = stmt.executeQuery(strSelect);
                                    while (rset1.next()) {
                                        idtmp = rset1.getInt("id") + 1;
                                    }


                                    String id = in.nextLine();
                                    String strselect = "SELECT proposal2.* FROM proposal2 WHERE proposal2.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        int idProp = rset.getInt("proposal2.id") ;
                                        int cid = rset.getInt("proposal2.cid");
                                        int quantity = rset.getInt("proposal2.quantity");
                                        float price = rset.getFloat("proposal2.value");
                                        String date = rset.getString("proposal2.date");
                                        String product = rset.getString("proposal2.product");

                                        String insertSql = "insert into proposal_tmp values (?, ?, ?, ?, ?, ?)";
                                        PreparedStatement pstmt = conn.prepareStatement(insertSql);

                                        Purchase p = new Purchase(idtmp,cid,product,date,quantity,price);

                                        pstmt.setInt(1, p.getId());
                                        pstmt.setInt(2, p.getCid());
                                        pstmt.setInt(3, Integer.parseInt(p.getProduct()));
                                        pstmt.setString(4, p.getDate());
                                        pstmt.setInt(5, p.getQuantity());
                                        pstmt.setDouble(6, p.getPrice());

                                        pstmt.addBatch();
                                        pstmt.executeBatch();

                                        /*//aggiungere alla tabella purchase_employee l'acquisto prendendo il prezzo dalla taballe wines_employee
                                        String strSelect2 = "SELECT * FROM wines_employee WHERE wines_employee.id='" + product + "'";
                                        ResultSet rset2 = stmt.executeQuery(strSelect2);
                                        float price2=0;
                                        while (rset2.next()) {
                                            price2 = rset2.getFloat("prize");
                                        }
                                        //aggiungere l'acquisto alla tabella purchase_employee
                                        String insertSql2 = "insert into purchase_employee values (?, ?, ?, ?, ?, ?)";
                                        PreparedStatement pstmt2 = conn.prepareStatement(insertSql2);

                                        Purchase p2 = new Purchase(idtmp,cid,product,date,quantity,(quantity*price2));

                                        pstmt2.setInt(1, p2.getId());
                                        pstmt2.setInt(2, p2.getCid());
                                        pstmt2.setInt(3, Integer.parseInt(p2.getProduct()));
                                        pstmt2.setString(4, p2.getDate());
                                        pstmt2.setInt(5, p2.getQuantity());
                                        pstmt2.setDouble(6, p2.getPrice());

                                        pstmt2.addBatch();
                                        pstmt2.executeBatch();*/



                                    }
                                    System.out.println(id);
                                    String deleteSql = "delete from proposal2 where id ='" + id + "'";
                                    PreparedStatement pstmt = conn.prepareStatement(deleteSql);
                                    pstmt.addBatch();
                                    pstmt.executeBatch();

                                }
                                else if(line.equals("REFUSE_PURCHASE")) {
                                    List<List<Integer>> listOfList = new ArrayList<>();

                                    String id = in.nextLine();
                                    String strselect = "SELECT proposal_tmp.* FROM proposal_tmp WHERE proposal_tmp.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);
                                    while (rset.next()) {
                                        int quantity = rset.getInt("proposal_tmp.quantity");
                                        String product = rset.getString("proposal_tmp.product");

                                        List<Integer> list = Arrays.asList(quantity, Integer.parseInt(product));
                                        listOfList.add(list);
                                    }
                                    rset.close();

                                    for (List<Integer> list : listOfList) {
                                        int quantity = list.get(0);
                                        int product = list.get(1);

                                        String strselect2 = "SELECT wines.* FROM wines WHERE wines.id='" + product + "'";
                                        ResultSet rset2 = stmt.executeQuery(strselect2);
                                        int quantityrem = 0;
                                        if (rset2.next()) {
                                            quantityrem = rset2.getInt("availability");
                                        }
                                        quantityrem = quantityrem + quantity;

                                        rset2.close();

                                        String updateSql = "UPDATE wines SET availability = ? WHERE id = ?";
                                        PreparedStatement pstmt2 = conn.prepareStatement(updateSql);
                                        pstmt2.setInt(1, quantityrem);
                                        pstmt2.setString(2, String.valueOf(product));
                                        pstmt2.executeUpdate();
                                        pstmt2.close();

                                    }
                                }
                                else if(line.equals("SEARCH_WINES_ON_SALE")) {
                                    String strselect = "SELECT discount.* FROM discount";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        String data = rset.getString("discount.wine") + "/" + rset.getInt("discount.discounts");
                                        out.println(data);
                                    }
                                    out.println("null");
                                }

                                else if(line.equals("ACCEPT_PROPOSAL_CLIENT")){
                                    String id = in.nextLine();
                                    String strselect = "SELECT proposal_tmp.* FROM proposal_tmp WHERE proposal_tmp.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        String data = rset.getString("proposal_tmp.product") + "/" + rset.getInt("proposal_tmp.quantity")+ "/" + id;
                                        out.println(data);
                                    }
                                    out.println("null");

                                    /*while (rset.next()) {
                                        int idProp = rset.getInt("proposal_tmp.id") ;
                                        int cid = rset.getInt("proposal_tmp.cid");
                                        int quantity = rset.getInt("proposal_tmp.quantity");
                                        float price = rset.getFloat("proposal_tmp.value");
                                        String date = rset.getString("proposal_tmp.date");
                                        String product = rset.getString("proposal_tmp.product");

                                        String insertSql = "insert into purchases values (?, ?, ?, ?, ?, ?)";
                                        PreparedStatement pstmt = conn.prepareStatement(insertSql);
                                        Purchase p = new Purchase(idProp,cid,product,date,quantity,price);

                                        pstmt.setInt(1, idProp);
                                        pstmt.setInt(2, p.getCid());
                                        pstmt.setInt(3, Integer.parseInt(p.getProduct()));
                                        pstmt.setString(4, p.getDate());
                                        pstmt.setInt(5, p.getQuantity());
                                        pstmt.setDouble(6, p.getPrice());

                                        pstmt.addBatch();
                                        pstmt.executeBatch();
                                    }
                                    String deleteSql = "delete from proposal_tmp where id ='" + id + "'";
                                    PreparedStatement pstmt = conn.prepareStatement(deleteSql);
                                    pstmt.addBatch();
                                    pstmt.executeBatch();*/
                                }

                                else if(line.equals("DELETE_PROPOSAL_TMP")){
                                    String id = in.nextLine();
                                    String deleteSql = "delete from proposal_tmp where id ='" + id + "'";
                                    PreparedStatement pstmt = conn.prepareStatement(deleteSql);
                                    pstmt.addBatch();
                                    pstmt.executeBatch();
                                }

                                else if(line.equals("DELETE_PROPOSAL_2")){
                                    String id = in.nextLine();
                                    String deleteSql = "delete from proposal2 where id ='" + id + "'";
                                    PreparedStatement pstmt = conn.prepareStatement(deleteSql);
                                    pstmt.addBatch();
                                    pstmt.executeBatch();
                                }

                                else if(line.equals("REFUSE_PROPOSAL_CLIENT")){
                                    String id = in.nextLine();
                                    String strselect = "SELECT proposal_tmp.product ,proposal_tmp.quantity FROM proposal_tmp WHERE proposal_tmp.id='" + id + "'";
                                    ResultSet rset = stmt.executeQuery(strselect);

                                    while (rset.next()) {
                                        int quantity = rset.getInt("proposal_tmp.quantity");
                                        String product = rset.getString("proposal_tmp.product");

                                        String insertSql = "UPDATE wines SET avaibility='" + quantity + "' WHERE wines.id='" + product + "'";
                                        PreparedStatement pstmt = conn.prepareStatement(insertSql);
                                    }

                                    String deleteSql = "delete from proposal_tmp where id ='" + id + "'";
                                    PreparedStatement pstmt = conn.prepareStatement(deleteSql);
                                    pstmt.addBatch();
                                    pstmt.executeBatch();
                                }

                                else if(line.equals("SALES")){
                                    String d1 = in.nextLine();
                                    String d2 = in.nextLine();
                                    String strselect;

                                    if (!d1.equals("null") && !d2.equals("null")) {

                                        strselect = "SELECT purchases.id, clients.name, wines.name, purchases.date, purchases.value, purchases.quantity FROM purchases INNER JOIN clients ON purchases.cid = clients.id INNER JOIN wines ON purchases.product = wines.id WHERE purchases.date BETWEEN '" + d1 + "' AND '" + d2 + "'";

                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases.id") + "/" + rset.getString("clients.name") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases.date") + "/" + rset.getFloat("purchases.value") + "/" + rset.getInt("purchases.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                    else if (d1.equals("null") && !d2.equals("null")) {

                                        strselect = "SELECT purchases.id, clients.name, wines.name, purchases.date, purchases.value, purchases.quantity FROM purchases INNER JOIN clients ON purchases.cid = clients.id INNER JOIN wines ON purchases.product = wines.id WHERE purchases.date <= '" + d2 + "'";

                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases.id") + "/" + rset.getString("clients.name") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases.date") + "/" + rset.getFloat("purchases.value") + "/" + rset.getInt("purchases.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                    else if (!d1.equals("null") && d2.equals("null")) {

                                        strselect = "SELECT purchases.id, clients.name, wines.name, purchases.date, purchases.value, purchases.quantity FROM purchases INNER JOIN clients ON purchases.cid = clients.id INNER JOIN wines ON purchases.product = wines.id WHERE purchases.date >= '" + d1 + "'";

                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases.id") + "/" + rset.getString("clients.name") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases.date") + "/" + rset.getFloat("purchases.value") + "/" + rset.getInt("purchases.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                    else {

                                        strselect = "SELECT purchases.id, clients.name, wines.name, purchases.date, purchases.value, purchases.quantity FROM purchases INNER JOIN clients ON purchases.cid = clients.id INNER JOIN wines ON purchases.product = wines.id";
                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases.id") + "/" + rset.getString("clients.name") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases.date") + "/" + rset.getFloat("purchases.value") + "/" + rset.getInt("purchases.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                        out.println("null");
                                    }
                                }

                                else if(line.equals("PURCHASE")){
                                    String d1 = in.nextLine();
                                    String d2 = in.nextLine();
                                    String strselect;

                                    if (!d1.equals("null") && !d2.equals("null")) {

                                        strselect = "SELECT purchases_employee.id, employees.username, wines.name, purchases_employee.date, purchases_employee.value, purchases_employee.quantity FROM purchases_employee INNER JOIN employees ON purchases_employee.cid = employees.id INNER JOIN wines ON purchases_employee.product = wines.id WHERE purchases_employee.date BETWEEN '" + d1 + "' AND '" + d2 + "'";
                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases_employee.id") + "/" + rset.getString("employees.username") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases_employee.date") + "/" + rset.getFloat("purchases_employee.value") + "/" + rset.getInt("purchases_employee.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                    else if (d1.equals("null") && !d2.equals("null")) {

                                        strselect = "SELECT purchases_employee.id, employees.username, wines.name, purchases_employee.date, purchases_employee.value, purchases_employee.quantity FROM purchases_employee INNER JOIN employees ON purchases_employee.cid = employees.id INNER JOIN wines ON purchases_employee.product = wines.id WHERE purchases_employee.date <= '" + d2 + "'";
                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases_employee.id") + "/" + rset.getString("employees.username") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases_employee.date") + "/" + rset.getFloat("purchases_employee.value") + "/" + rset.getInt("purchases_employee.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                    else if (!d1.equals("null") && d2.equals("null")) {

                                        strselect = "SELECT purchases_employee.id, employees.username, wines.name, purchases_employee.date, purchases_employee.value, purchases_employee.quantity FROM purchases_employee INNER JOIN employees ON purchases_employee.cid = employees.id INNER JOIN wines ON purchases_employee.product = wines.id WHERE purchases_employee.date >= '" + d1 + "'";
                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases_employee.id") + "/" + rset.getString("employees.username") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases_employee.date") + "/" + rset.getFloat("purchases_employee.value") + "/" + rset.getInt("purchases_employee.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                    else {

                                        strselect = "SELECT purchases_employee.id, employees.username, wines.name, purchases_employee.date, purchases_employee.value, purchases_employee.quantity FROM purchases_employee INNER JOIN employees ON purchases_employee.cid = employees.id INNER JOIN wines ON purchases_employee.product = wines.id";
                                        ResultSet rset = stmt.executeQuery(strselect);

                                        while (rset.next()) {
                                            String data =rset.getInt("purchases_employee.id") + "/" + rset.getString("employees.username") + "/" + rset.getString("wines.name") + "/" + rset.getString("purchases_employee.date") + "/" + rset.getFloat("purchases_employee.value") + "/" + rset.getInt("purchases_employee.quantity");
                                            out.println(data);
                                        }
                                        out.println("null");
                                    }
                                }




                                else if(line.equals("PROPOSAL_BUY_WINES"))
                                {

                                    String id = in.nextLine();
                                    int quantity = Integer.parseInt(in.nextLine());
                                    int cid = Integer.parseInt(in.nextLine());
                                    int contproposal = Integer.parseInt(in.nextLine());
                                    float price_tot=Float.parseFloat(in.nextLine());

                                    String date = String.valueOf(LocalDate.now());

                                    String insertSql = "insert into proposal2 values (?, ?, ?, ?, ?, ?)";
                                    PreparedStatement pstmt = conn.prepareStatement(insertSql);
                                    Purchase p = new Purchase(contproposal, cid, id, date, quantity , price_tot);

                                    pstmt.setInt(1, contproposal);
                                    pstmt.setInt(2, p.getCid());
                                    pstmt.setInt(3, Integer.parseInt(p.getProduct()));
                                    pstmt.setString(4, p.getDate());
                                    pstmt.setInt(5, p.getQuantity());
                                    pstmt.setDouble(6, p.getPrice());

                                    pstmt.addBatch();
                                    pstmt.executeBatch();

                                }
                            }
                        }
                        catch(SQLException | IOException e){
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        }catch (IOException | SQLException e) {

        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}



