package com.example.progettodbfx;

import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Discount {
    BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static final String DBURL = "jdbc:mysql://127.0.0.1:3306/Wineshop?";
    private static final String ARGS = "createDatabaseIfNotExist=true&serverTimezone=UTC";
    private static final String LOGIN = "root";
    private static final String PASSWORD = "";

    private String discount;
    private String wine;

    public Discount(String wine,String discount) {
        this.wine = wine;
        this.discount = discount;
    }
    public void setDiscount(String discount) {
        this.discount = discount;
    }
    public String getDiscount() {
        return discount;
    }
    public void setWine(String wine) {
        this.wine = wine;
    }
    public String getWine() {
        return wine;
    }


}
